@extends('layouts.app')
@section('content')
<div class="images">
    
</div>

@endsection

 
