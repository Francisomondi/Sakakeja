<footer id="footer" class="text text-center">
<p>Copyright &copy 2018 Francis Omondi</p>
  <div></div>
</footer>
        
 