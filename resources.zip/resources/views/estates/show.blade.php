@extends('layouts.app')
@section('content')

   Estates
@endsection
